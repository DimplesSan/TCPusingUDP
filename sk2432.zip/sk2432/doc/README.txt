1) Extract the archive into a local working directory.
2) Navigate in to the extracted directory
3) The source files are located at --> /sk2432/src
   the binary files are located at --> /sk2432/bin
4) Navigate to the /sk2432/bin directory to excute the program.

   NOTE: If binary files are not present then, compile the source code from 
   the src directory using the following command,

   javac ../src/*.java -d ../bin/

   To execute the program, use the following command,

   java fcntcp -{c,s} [options] [server address] port
   
   options:
   -c, --client : run as client
   -s, --server : run as server
   -f <file>, --file: specify file for client to send. client applications
   -t <#>, --timeout: timeout in milliseconds for retransmit timer.
           Default to 1000 mS (1 second) if not specified. client applications
   -q, --quiet: do not output detailed diagnostics. client & server applications
   server address : address of server to connect to. client applications.
   port : primary connection port client & server applications

5) ENSURE that the specified file name (using the -f option) is present in the
   /bin directory.

